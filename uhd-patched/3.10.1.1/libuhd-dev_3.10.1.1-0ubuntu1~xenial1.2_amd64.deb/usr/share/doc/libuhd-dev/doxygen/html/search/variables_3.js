var searchData=
[
  ['channel',['channel',['../structuhd_1_1async__metadata__t.html#aa17b8f14b9ddafca72ef869496723925',1,'uhd::async_metadata_t']]],
  ['channel_5flist',['channel_list',['../structuhd__stream__args__t.html#aba4933e6c75e28e9c267f089c7f7bd96',1,'uhd_stream_args_t']]],
  ['channels',['channels',['../structuhd_1_1stream__args__t.html#aebfb903c0cb6c040d78ef90917e55a61',1,'uhd::stream_args_t']]],
  ['cid',['cid',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#af62653022a572ca25e58207612857116',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['clipped_5frf_5ffreq',['clipped_rf_freq',['../structuhd__tune__result__t.html#a1179065a82f6d8d4855462a5c3a41ee9',1,'uhd_tune_result_t::clipped_rf_freq()'],['../structuhd_1_1tune__result__t.html#a56e0333fe253ea3af45c8d7a74f6ce7e',1,'uhd::tune_result_t::clipped_rf_freq()']]],
  ['cpu_5fformat',['cpu_format',['../structuhd_1_1stream__args__t.html#a602a64b4937a85dba84e7f724387e252',1,'uhd::stream_args_t::cpu_format()'],['../structuhd__stream__args__t.html#a22234f7a37ff543b99f88293146452d1',1,'uhd_stream_args_t::cpu_format()']]]
];
