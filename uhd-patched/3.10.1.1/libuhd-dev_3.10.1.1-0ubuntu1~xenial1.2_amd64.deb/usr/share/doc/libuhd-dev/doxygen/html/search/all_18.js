var searchData=
[
  ['zero_5fcopy_2ehpp',['zero_copy.hpp',['../zero__copy_8hpp.html',1,'']]],
  ['zero_5fcopy_5fif',['zero_copy_if',['../classuhd_1_1transport_1_1zero__copy__if.html',1,'uhd::transport']]],
  ['zero_5fcopy_5frecv_5foffload',['zero_copy_recv_offload',['../classuhd_1_1transport_1_1zero__copy__recv__offload.html',1,'uhd::transport']]],
  ['zero_5fcopy_5frecv_5foffload_2ehpp',['zero_copy_recv_offload.hpp',['../zero__copy__recv__offload_8hpp.html',1,'']]],
  ['zero_5fcopy_5fxport_5fparams',['zero_copy_xport_params',['../structuhd_1_1transport_1_1zero__copy__xport__params.html',1,'uhd::transport']]]
];
