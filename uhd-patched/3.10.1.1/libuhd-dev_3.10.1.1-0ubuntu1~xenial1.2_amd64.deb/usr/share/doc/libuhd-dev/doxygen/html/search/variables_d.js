var searchData=
[
  ['otw_5fformat',['otw_format',['../structuhd_1_1stream__args__t.html#a0ba0e946d2f83f7ac085f4f4e2ce9578',1,'uhd::stream_args_t::otw_format()'],['../structuhd__stream__args__t.html#a06719a92d67f3c57307ed4c7b704b735',1,'uhd_stream_args_t::otw_format()']]],
  ['out_5fof_5fsequence',['out_of_sequence',['../structuhd_1_1rx__metadata__t.html#a1bd09159cf5f2109cfa168758213ddee',1,'uhd::rx_metadata_t']]],
  ['output_5fformat',['output_format',['../structuhd_1_1convert_1_1id__type.html#a68c2e95fc10706120528c597504065b8',1,'uhd::convert::id_type']]]
];
