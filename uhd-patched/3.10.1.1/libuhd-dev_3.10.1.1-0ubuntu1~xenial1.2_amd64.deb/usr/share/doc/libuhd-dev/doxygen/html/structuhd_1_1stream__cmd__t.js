var structuhd_1_1stream__cmd__t =
[
    [ "stream_mode_t", "structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904", [
      [ "STREAM_MODE_START_CONTINUOUS", "structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a91fa979980d1a6de6bf861b8459ed5c3", null ],
      [ "STREAM_MODE_STOP_CONTINUOUS", "structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a2321e3ab62fd02772298e41e94a32f9f", null ],
      [ "STREAM_MODE_NUM_SAMPS_AND_DONE", "structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a0e293a4a7cab198a4f6cb0e196ca377d", null ],
      [ "STREAM_MODE_NUM_SAMPS_AND_MORE", "structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a1e32ed6ef38e60377d62495a6e7c51be", null ]
    ] ],
    [ "stream_cmd_t", "structuhd_1_1stream__cmd__t.html#aff834ed8ccba992d53649bd1f18c8cbb", null ],
    [ "num_samps", "structuhd_1_1stream__cmd__t.html#a60be4a415f9b72e1dc3bd5903a78c492", null ],
    [ "stream_mode", "structuhd_1_1stream__cmd__t.html#a72ed4ca83c9b57d9f0f058857f1f4a52", null ],
    [ "stream_now", "structuhd_1_1stream__cmd__t.html#a0b2ebd1dedd814355c3fcd51af7d1eb1", null ],
    [ "time_spec", "structuhd_1_1stream__cmd__t.html#adfa4540f74b0cc62855a295422655fbe", null ]
];