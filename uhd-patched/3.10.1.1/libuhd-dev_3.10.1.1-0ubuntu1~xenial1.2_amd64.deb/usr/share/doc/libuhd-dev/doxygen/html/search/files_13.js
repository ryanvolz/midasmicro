var searchData=
[
  ['zero_5fcopy_2ehpp',['zero_copy.hpp',['../zero__copy_8hpp.html',1,'']]],
  ['zero_5fcopy_5frecv_5foffload_2ehpp',['zero_copy_recv_offload.hpp',['../zero__copy__recv__offload_8hpp.html',1,'']]]
];
