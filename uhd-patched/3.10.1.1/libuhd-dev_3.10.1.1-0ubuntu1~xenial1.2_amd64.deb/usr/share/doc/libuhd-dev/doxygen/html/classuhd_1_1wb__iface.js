var classuhd_1_1wb__iface =
[
    [ "sptr", "classuhd_1_1wb__iface.html#a2369ba0ac501d4b309f181063c13aa3f", null ],
    [ "wb_addr_type", "classuhd_1_1wb__iface.html#a128b63e1091ed63c5bb164195164f46e", null ],
    [ "~wb_iface", "classuhd_1_1wb__iface.html#a77a19452ba6946c417ba025cef7fc6b4", null ],
    [ "peek16", "classuhd_1_1wb__iface.html#a02f2344b57aaacb821814ae47e24acc5", null ],
    [ "peek32", "classuhd_1_1wb__iface.html#ac5b14390cc8d04488b91ba292227d974", null ],
    [ "peek64", "classuhd_1_1wb__iface.html#a5499b79a442a44c459915a248f608bd9", null ],
    [ "poke16", "classuhd_1_1wb__iface.html#afc579227364ba65b2285b9948cd714da", null ],
    [ "poke32", "classuhd_1_1wb__iface.html#ad91be3b8c862b74e7b26533e6f10fef7", null ],
    [ "poke64", "classuhd_1_1wb__iface.html#a6a1b5d8f4fc6e331a0a653943c7a4e58", null ]
];