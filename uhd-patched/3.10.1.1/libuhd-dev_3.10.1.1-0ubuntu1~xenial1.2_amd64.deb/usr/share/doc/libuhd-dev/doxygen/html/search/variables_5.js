var searchData=
[
  ['end_5fof_5fburst',['end_of_burst',['../structuhd_1_1rx__metadata__t.html#a69e306add401a7e0a0caa5e30d6ee5ce',1,'uhd::rx_metadata_t::end_of_burst()'],['../structuhd_1_1tx__metadata__t.html#a00543aaaeb5a5d67b212778d6b5f1b53',1,'uhd::tx_metadata_t::end_of_burst()']]],
  ['eob',['eob',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a6873bfffa90438a78307045d29191660',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['error',['error',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#aff48430515718b7e075f49921529edad',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['error_5fcode',['error_code',['../structuhd_1_1rx__metadata__t.html#ab0a70db215d88d013c6b71e132ac3b54',1,'uhd::rx_metadata_t']]],
  ['event_5fcode',['event_code',['../structuhd_1_1async__metadata__t.html#a84f8135361b384da656e3f1bd8756bc8',1,'uhd::async_metadata_t']]]
];
