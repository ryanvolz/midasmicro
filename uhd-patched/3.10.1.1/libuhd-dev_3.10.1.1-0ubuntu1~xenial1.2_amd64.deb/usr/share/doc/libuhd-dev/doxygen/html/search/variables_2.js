var searchData=
[
  ['bcast',['bcast',['../structuhd_1_1transport_1_1if__addrs__t.html#af5211dfae676fe6ec5b0fb7378f43968',1,'uhd::transport::if_addrs_t']]],
  ['bitwidth',['bitwidth',['../structuhd_1_1usrp_1_1multi__usrp_1_1register__info__t.html#a2b9859e7a498b0ce9098d37bbbb556a6',1,'uhd::usrp::multi_usrp::register_info_t::bitwidth()'],['../structuhd__usrp__register__info__t.html#ac41c902e2b6c57bcfc59c7765e5adfbb',1,'uhd_usrp_register_info_t::bitwidth()']]],
  ['byteorder',['byteorder',['../structuhd_1_1otw__type__t.html#a8d9ea1457c64ae68b3db89be5a5288a4',1,'uhd::otw_type_t']]]
];
