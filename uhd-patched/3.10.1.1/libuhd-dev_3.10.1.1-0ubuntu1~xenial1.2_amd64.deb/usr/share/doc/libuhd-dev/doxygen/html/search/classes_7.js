var searchData=
[
  ['gain_5ffcns_5ft',['gain_fcns_t',['../structuhd_1_1gain__fcns__t.html',1,'uhd']]],
  ['gain_5fgroup',['gain_group',['../classuhd_1_1gain__group.html',1,'uhd']]],
  ['gps_5fctrl',['gps_ctrl',['../classuhd_1_1gps__ctrl.html',1,'uhd']]]
];
