var searchData=
[
  ['integer',['INTEGER',['../structuhd_1_1sensor__value__t.html#a1f6bf20f81b094c002bf06e3903a37e1a4a2aba4eb1ecd810969cc49619d56dd6',1,'uhd::sensor_value_t']]]
];
