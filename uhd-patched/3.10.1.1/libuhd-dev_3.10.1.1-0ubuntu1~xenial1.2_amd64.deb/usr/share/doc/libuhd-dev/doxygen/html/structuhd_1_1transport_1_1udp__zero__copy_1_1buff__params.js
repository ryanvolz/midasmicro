var structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params =
[
    [ "recv_buff_size", "structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params.html#aa15c217c285752cb8a790b0bc9ff6b51", null ],
    [ "send_buff_size", "structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params.html#a8685f52397386257eb6a3bc58f9264dd", null ]
];