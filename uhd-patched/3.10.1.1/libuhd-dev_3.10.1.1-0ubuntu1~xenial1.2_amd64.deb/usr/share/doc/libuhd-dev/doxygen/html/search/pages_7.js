var searchData=
[
  ['multiple_20usrp_20configurations',['Multiple USRP configurations',['../page_multiple.html',1,'page_devices']]]
];
