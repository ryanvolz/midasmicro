var searchData=
[
  ['buffs_5ftype',['buffs_type',['../classuhd_1_1rx__streamer.html#a25d1b4cbd0233a8b7a692503053438ac',1,'uhd::rx_streamer::buffs_type()'],['../classuhd_1_1tx__streamer.html#a06f6341bfa89bc755f262cbbfb616fbd',1,'uhd::tx_streamer::buffs_type()']]],
  ['byte_5fvector_5ft',['byte_vector_t',['../namespaceuhd.html#a28ea5360abdd1fee2ee39ac228f54e1a',1,'uhd']]]
];
