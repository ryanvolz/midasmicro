var searchData=
[
  ['bo_5fbig_5fendian',['BO_BIG_ENDIAN',['../structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983a5c9d721ec8edfb899b1704cd70904be4',1,'uhd::otw_type_t']]],
  ['bo_5flittle_5fendian',['BO_LITTLE_ENDIAN',['../structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983a0c2f7178dbea0ef02c45bae7a1d8d646',1,'uhd::otw_type_t']]],
  ['bo_5fnative',['BO_NATIVE',['../structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983af2dc214b6aef4ba3caa49b18041867b6',1,'uhd::otw_type_t']]],
  ['bo_5fnot_5fapplicable',['BO_NOT_APPLICABLE',['../structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983aa26e4bff795c8269b2db19aa887c2b4c',1,'uhd::otw_type_t']]],
  ['boolean',['BOOLEAN',['../structuhd_1_1sensor__value__t.html#a1f6bf20f81b094c002bf06e3903a37e1a67990358f836e48528775f518d975469',1,'uhd::sensor_value_t']]]
];
