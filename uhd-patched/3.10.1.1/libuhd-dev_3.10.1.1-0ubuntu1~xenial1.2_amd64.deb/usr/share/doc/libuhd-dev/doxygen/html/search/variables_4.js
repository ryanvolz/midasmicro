var searchData=
[
  ['db_5fname',['db_name',['../structuhd__subdev__spec__pair__t.html#afd1e28bfa340e2a33a6bb11f51c5a35e',1,'uhd_subdev_spec_pair_t::db_name()'],['../structuhd_1_1usrp_1_1subdev__spec__pair__t.html#ad49c2e1a14892c3dadccd2bd74908bae',1,'uhd::usrp::subdev_spec_pair_t::db_name()']]],
  ['divider',['divider',['../structuhd_1_1spi__config__t.html#ae46f9054e2387ed727b94825d02097b2',1,'uhd::spi_config_t']]],
  ['dsp_5ffreq',['dsp_freq',['../structuhd__tune__request__t.html#a4ec2f1725cde3ff303c0a758df21000d',1,'uhd_tune_request_t::dsp_freq()'],['../structuhd_1_1tune__request__t.html#a616cd26b5d26bfa04909ab2304770492',1,'uhd::tune_request_t::dsp_freq()']]],
  ['dsp_5ffreq_5fpolicy',['dsp_freq_policy',['../structuhd__tune__request__t.html#a1bf66d6d89470a64f6859e692a49f8fb',1,'uhd_tune_request_t::dsp_freq_policy()'],['../structuhd_1_1tune__request__t.html#a1f71eca0239d2e9ff5744417c9a49a74',1,'uhd::tune_request_t::dsp_freq_policy()']]]
];
