var structuhd_1_1clock__config__t =
[
    [ "pps_polarity_t", "structuhd_1_1clock__config__t.html#aaaebc21578470764e3a1a5dda370ad41", [
      [ "PPS_NEG", "structuhd_1_1clock__config__t.html#aaaebc21578470764e3a1a5dda370ad41ae7116a104751fed3f0550bbe39ffe54b", null ],
      [ "PPS_POS", "structuhd_1_1clock__config__t.html#aaaebc21578470764e3a1a5dda370ad41aeada90db008ac0f26bffc3d57cde241c", null ]
    ] ],
    [ "pps_source_t", "structuhd_1_1clock__config__t.html#ada8c944753b43d9e96f1483095f304a7", [
      [ "PPS_INT", "structuhd_1_1clock__config__t.html#ada8c944753b43d9e96f1483095f304a7a50b119aa73567aa4afb6f063f5defde8", null ],
      [ "PPS_SMA", "structuhd_1_1clock__config__t.html#ada8c944753b43d9e96f1483095f304a7af0024ec53e8af09abb6f03eba7bcc2e5", null ],
      [ "PPS_MIMO", "structuhd_1_1clock__config__t.html#ada8c944753b43d9e96f1483095f304a7afd90c1346a698370a35e8467606c95f1", null ]
    ] ],
    [ "ref_source_t", "structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8", [
      [ "REF_AUTO", "structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a0cd1a6af945efe76261cfd65205d19ea", null ],
      [ "REF_INT", "structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a9ad0997c6d416fecf103d9dda252c531", null ],
      [ "REF_SMA", "structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a03906cbc61ffb609f69c726241f0014d", null ],
      [ "REF_MIMO", "structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a29f14a026c34003ed410ef189d4b8a4e", null ]
    ] ],
    [ "clock_config_t", "structuhd_1_1clock__config__t.html#aa219f6c9abc1a98b0f30f276eb678407", null ],
    [ "pps_polarity", "structuhd_1_1clock__config__t.html#a3bbd5a2a58634d023fa99a9af991ba63", null ],
    [ "pps_source", "structuhd_1_1clock__config__t.html#a934e98b48a62dba3b02d277812452674", null ],
    [ "ref_source", "structuhd_1_1clock__config__t.html#abb02daff4e4a3a270f86ec5182ff4b2a", null ]
];