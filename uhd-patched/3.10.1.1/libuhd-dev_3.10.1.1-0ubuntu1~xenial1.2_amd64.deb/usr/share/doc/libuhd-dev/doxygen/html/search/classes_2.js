var searchData=
[
  ['bounded_5fbuffer',['bounded_buffer',['../classuhd_1_1transport_1_1bounded__buffer.html',1,'uhd::transport']]],
  ['bounded_5fbuffer_5fdetail',['bounded_buffer_detail',['../classuhd_1_1transport_1_1bounded__buffer__detail.html',1,'uhd::transport']]],
  ['buff_5fparams',['buff_params',['../structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params.html',1,'uhd::transport::udp_zero_copy']]],
  ['buffer_5fpool',['buffer_pool',['../classuhd_1_1transport_1_1buffer__pool.html',1,'uhd::transport']]]
];
