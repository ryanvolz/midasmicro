var searchData=
[
  ['loader_5ffcn_5ft',['loader_fcn_t',['../classuhd_1_1image__loader.html#adb27aa4abf139ba9e4bc5f7821ede1c9',1,'uhd::image_loader']]]
];
