var time__spec_8hpp =
[
    [ "time_spec_t", "classuhd_1_1time__spec__t.html", "classuhd_1_1time__spec__t" ],
    [ "operator<", "time__spec_8hpp.html#a5c44da6b9ff6024bd84063273323e015", null ],
    [ "operator==", "time__spec_8hpp.html#a493a9edc85b83ed91c909670a259a6bd", null ]
];