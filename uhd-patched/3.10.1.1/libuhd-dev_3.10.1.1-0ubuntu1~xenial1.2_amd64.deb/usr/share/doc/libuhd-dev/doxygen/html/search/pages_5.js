var searchData=
[
  ['general_20application_20notes',['General Application Notes',['../page_general.html',1,'page_devices']]]
];
