var searchData=
[
  ['xcvr_5fdboard_5fbase',['xcvr_dboard_base',['../classuhd_1_1usrp_1_1xcvr__dboard__base.html',1,'uhd::usrp']]],
  ['xcvr_5fdboard_5fbase',['xcvr_dboard_base',['../classuhd_1_1usrp_1_1xcvr__dboard__base.html#a6356d55d86cd087add4d4494ec0d63f0',1,'uhd::usrp::xcvr_dboard_base']]],
  ['xstr',['XSTR',['../config_8hpp.html#aa1a519fd32410ce257ca4a54477bd454',1,'config.hpp']]]
];
