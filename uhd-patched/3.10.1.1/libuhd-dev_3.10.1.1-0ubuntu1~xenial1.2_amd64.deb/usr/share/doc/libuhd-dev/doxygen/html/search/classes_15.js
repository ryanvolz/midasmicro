var searchData=
[
  ['xcvr_5fdboard_5fbase',['xcvr_dboard_base',['../classuhd_1_1usrp_1_1xcvr__dboard__base.html',1,'uhd::usrp']]]
];
