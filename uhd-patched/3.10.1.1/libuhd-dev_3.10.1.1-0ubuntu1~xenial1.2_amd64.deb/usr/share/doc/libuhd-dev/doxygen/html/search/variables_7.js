var searchData=
[
  ['get_5frange',['get_range',['../structuhd_1_1gain__fcns__t.html#a15afcd690820105a776fca61ca792592',1,'uhd::gain_fcns_t']]],
  ['get_5fvalue',['get_value',['../structuhd_1_1gain__fcns__t.html#aba768401111493b84ebf6c7ec96fa484',1,'uhd::gain_fcns_t']]]
];
