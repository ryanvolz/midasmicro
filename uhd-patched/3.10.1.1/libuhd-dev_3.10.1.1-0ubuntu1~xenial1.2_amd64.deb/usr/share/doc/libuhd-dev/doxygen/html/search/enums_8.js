var searchData=
[
  ['recv_5fmode_5ft',['recv_mode_t',['../device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2baf',1,'device_deprecated.ipp']]],
  ['ref_5fsource_5ft',['ref_source_t',['../structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8',1,'uhd::clock_config_t']]]
];
