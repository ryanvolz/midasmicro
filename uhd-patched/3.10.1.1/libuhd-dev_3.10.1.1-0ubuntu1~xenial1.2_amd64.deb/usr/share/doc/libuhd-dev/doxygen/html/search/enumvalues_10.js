var searchData=
[
  ['send_5fmode_5ffull_5fbuff',['SEND_MODE_FULL_BUFF',['../device__deprecated_8ipp.html#ae952a83b7868c74e272789e347e92b58a0d4108ad751d15ae5bc51cbc934deb07',1,'device_deprecated.ipp']]],
  ['send_5fmode_5fone_5fpacket',['SEND_MODE_ONE_PACKET',['../device__deprecated_8ipp.html#ae952a83b7868c74e272789e347e92b58a0233b3d5533375c566fba28ebcb29e81',1,'device_deprecated.ipp']]],
  ['status',['status',['../namespaceuhd_1_1msg.html#a39e78d22a268a4f0375423a1d588139ba4a6791e1c064188a13d6a802e0fe073a',1,'uhd::msg']]],
  ['stream_5fmode_5fnum_5fsamps_5fand_5fdone',['STREAM_MODE_NUM_SAMPS_AND_DONE',['../structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a0e293a4a7cab198a4f6cb0e196ca377d',1,'uhd::stream_cmd_t']]],
  ['stream_5fmode_5fnum_5fsamps_5fand_5fmore',['STREAM_MODE_NUM_SAMPS_AND_MORE',['../structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a1e32ed6ef38e60377d62495a6e7c51be',1,'uhd::stream_cmd_t']]],
  ['stream_5fmode_5fstart_5fcontinuous',['STREAM_MODE_START_CONTINUOUS',['../structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a91fa979980d1a6de6bf861b8459ed5c3',1,'uhd::stream_cmd_t']]],
  ['stream_5fmode_5fstop_5fcontinuous',['STREAM_MODE_STOP_CONTINUOUS',['../structuhd_1_1stream__cmd__t.html#a4df1f2e22148b7e09ace0eca0dfbf904a2321e3ab62fd02772298e41e94a32f9f',1,'uhd::stream_cmd_t']]],
  ['string',['STRING',['../structuhd_1_1sensor__value__t.html#a1f6bf20f81b094c002bf06e3903a37e1adbeee2b0ceac9a9f1aa4ae8ea7fdfc0a',1,'uhd::sensor_value_t']]]
];
