var structuhd_1_1key__error =
[
    [ "key_error", "structuhd_1_1key__error.html#a00ff63f412fa7751c818fd7ec9cc0103", null ],
    [ "code", "structuhd_1_1key__error.html#a6a67e662b8d1091e4c6fedf157643be1", null ],
    [ "dynamic_clone", "structuhd_1_1key__error.html#a35f68afd32c1fb433833ae0e8096fbea", null ],
    [ "dynamic_throw", "structuhd_1_1key__error.html#a5237205a60f728740fbfe4e42af95a4e", null ]
];