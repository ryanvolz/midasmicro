var searchData=
[
  ['readable',['readable',['../structuhd_1_1usrp_1_1multi__usrp_1_1register__info__t.html#a067aa54fac00256661655539562e9fad',1,'uhd::usrp::multi_usrp::register_info_t::readable()'],['../structuhd__usrp__register__info__t.html#af151005503064ae5048927204f340034',1,'uhd_usrp_register_info_t::readable()']]],
  ['recv_5fbuff_5fsize',['recv_buff_size',['../structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params.html#aa15c217c285752cb8a790b0bc9ff6b51',1,'uhd::transport::udp_zero_copy::buff_params']]],
  ['recv_5fframe_5fsize',['recv_frame_size',['../structuhd_1_1transport_1_1zero__copy__xport__params.html#a16fb4cf4bb36e46224d6df81697668cb',1,'uhd::transport::zero_copy_xport_params']]],
  ['ref_5fsource',['ref_source',['../structuhd_1_1clock__config__t.html#abb02daff4e4a3a270f86ec5182ff4b2a',1,'uhd::clock_config_t']]],
  ['register',['REGISTER',['../classuhd_1_1soft__register__t.html#a6eaa0801948fb4283f4bd1b9181de267',1,'uhd::soft_register_t']]],
  ['revision',['revision',['../structuhd_1_1usrp_1_1dboard__eeprom__t.html#a28f9c91fc3f1c521dc0db48f7c6c64d1',1,'uhd::usrp::dboard_eeprom_t']]],
  ['rf_5ffreq',['rf_freq',['../structuhd__tune__request__t.html#a3e43dee534717535fcd446bbf84ad504',1,'uhd_tune_request_t::rf_freq()'],['../structuhd_1_1tune__request__t.html#aa646a0b00b7ee1ddb570fbe3a93e17fc',1,'uhd::tune_request_t::rf_freq()']]],
  ['rf_5ffreq_5fpolicy',['rf_freq_policy',['../structuhd__tune__request__t.html#ad0886b163d96e0daea21be2245fbf1e8',1,'uhd_tune_request_t::rf_freq_policy()'],['../structuhd_1_1tune__request__t.html#ad75b9d6fd97c95fb95fc04971b58fd39',1,'uhd::tune_request_t::rf_freq_policy()']]],
  ['rx_5fantenna',['rx_antenna',['../structuhd__usrp__rx__info__t.html#a11931fe71b985f280c938368246b3a0b',1,'uhd_usrp_rx_info_t']]],
  ['rx_5fid',['rx_id',['../structuhd__usrp__rx__info__t.html#a071e53c53deae796dbc2e94dd02e56f7',1,'uhd_usrp_rx_info_t']]],
  ['rx_5fserial',['rx_serial',['../structuhd__usrp__rx__info__t.html#a10996887eb2b2214dc1d5b9dd27b065f',1,'uhd_usrp_rx_info_t']]],
  ['rx_5fsubdev_5fname',['rx_subdev_name',['../structuhd__usrp__rx__info__t.html#a239f999f4045df42bbf294900eb47e3d',1,'uhd_usrp_rx_info_t']]],
  ['rx_5fsubdev_5fspec',['rx_subdev_spec',['../structuhd__usrp__rx__info__t.html#a63bf2a92f19afb16594ca9fb63cbf9bb',1,'uhd_usrp_rx_info_t']]]
];
