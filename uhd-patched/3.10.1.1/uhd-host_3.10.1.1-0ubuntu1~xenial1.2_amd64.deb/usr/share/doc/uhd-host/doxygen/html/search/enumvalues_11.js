var searchData=
[
  ['tx_5fdirection',['TX_DIRECTION',['../namespaceuhd.html#a15fbb7809a271ea929ea2390624eb425a9efb9f316c5e131460dd2cd2079a87be',1,'uhd']]]
];
