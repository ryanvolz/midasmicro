var searchData=
[
  ['firmware_5fpath',['firmware_path',['../structuhd_1_1image__loader_1_1image__loader__args__t.html#ac6e992e74fcfcceb3dd67790614f4bd4',1,'uhd::image_loader::image_loader_args_t']]],
  ['fpga_5fpath',['fpga_path',['../structuhd_1_1image__loader_1_1image__loader__args__t.html#aafd3ab71283b25ad991b293741166d9b',1,'uhd::image_loader::image_loader_args_t']]],
  ['fragment_5foffset',['fragment_offset',['../structuhd_1_1rx__metadata__t.html#aec8f2278ac684af1ca3ac22ddec668ca',1,'uhd::rx_metadata_t']]]
];
