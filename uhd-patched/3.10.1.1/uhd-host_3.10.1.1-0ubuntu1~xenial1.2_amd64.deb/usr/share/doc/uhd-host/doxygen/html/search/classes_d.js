var searchData=
[
  ['octoclock_5feeprom_5ft',['octoclock_eeprom_t',['../classuhd_1_1usrp__clock_1_1octoclock__eeprom__t.html',1,'uhd::usrp_clock']]],
  ['os_5ferror',['os_error',['../structuhd_1_1os__error.html',1,'uhd']]],
  ['otw_5ftype_5ft',['otw_type_t',['../structuhd_1_1otw__type__t.html',1,'uhd']]]
];
