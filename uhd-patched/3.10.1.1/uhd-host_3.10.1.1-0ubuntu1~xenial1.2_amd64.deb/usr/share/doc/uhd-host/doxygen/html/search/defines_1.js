var searchData=
[
  ['boost_5fipc_5fdetail',['BOOST_IPC_DETAIL',['../atomic_8hpp.html#a9c44e656bd6e88bbde00d37b1e09cda5',1,'atomic.hpp']]]
];
