var searchData=
[
  ['n_5fchannels',['n_channels',['../structuhd__stream__args__t.html#a5bde43c4ca7f50431861453a0cb45241',1,'uhd_stream_args_t']]],
  ['name',['name',['../structuhd_1_1sensor__value__t.html#ac5792e372455f5d4ac945d5c6073c0a0',1,'uhd::sensor_value_t']]],
  ['num_5fheader_5fwords32',['num_header_words32',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#aff387148e3f0d739f09816776bc06176',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['num_5finputs',['num_inputs',['../structuhd_1_1convert_1_1id__type.html#a7d7844ad931bd77647e0f04e14dace82',1,'uhd::convert::id_type']]],
  ['num_5foutputs',['num_outputs',['../structuhd_1_1convert_1_1id__type.html#af42d6220c0fd741f93841f4125710870',1,'uhd::convert::id_type']]],
  ['num_5fpacket_5fwords32',['num_packet_words32',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a734aa3e8bdc9db176c0f52b0b66132d3',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['num_5fpayload_5fbytes',['num_payload_bytes',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a708b649b3cb7c54cde707b93a31caca8',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['num_5fpayload_5fwords32',['num_payload_words32',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#ae9b8baf85d44c7b91a6b27d139f5b1d8',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['num_5frecv_5fframes',['num_recv_frames',['../structuhd_1_1transport_1_1zero__copy__xport__params.html#a05832937ccd7aabc891f331a2fd4b915',1,'uhd::transport::zero_copy_xport_params']]],
  ['num_5fsamps',['num_samps',['../structuhd_1_1stream__cmd__t.html#a60be4a415f9b72e1dc3bd5903a78c492',1,'uhd::stream_cmd_t::num_samps()'],['../structuhd__stream__cmd__t.html#afe015eed3c5fde54c0eed00a9b39e537',1,'uhd_stream_cmd_t::num_samps()']]],
  ['num_5fsend_5fframes',['num_send_frames',['../structuhd_1_1transport_1_1zero__copy__xport__params.html#a6dee1be80a77e669929cc3136d679d84',1,'uhd::transport::zero_copy_xport_params']]]
];
