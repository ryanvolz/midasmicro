var searchData=
[
  ['vid_5fpid_5fpair_5ft',['vid_pid_pair_t',['../classuhd_1_1transport_1_1usb__device__handle.html#ae52620333fed7cd947c397859900e5f4',1,'uhd::transport::usb_device_handle']]]
];
