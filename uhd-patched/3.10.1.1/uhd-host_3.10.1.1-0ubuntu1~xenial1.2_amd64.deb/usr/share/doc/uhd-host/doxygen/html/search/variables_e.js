var searchData=
[
  ['packet_5fcount',['packet_count',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a87ced31ed311ba8c4bd6113844d64abf',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['packet_5ftype',['packet_type',['../structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a9e761f9501aa6f7a5f8034e12c5453e6',1,'uhd::transport::vrt::if_packet_info_t']]],
  ['pps_5fpolarity',['pps_polarity',['../structuhd_1_1clock__config__t.html#a3bbd5a2a58634d023fa99a9af991ba63',1,'uhd::clock_config_t']]],
  ['pps_5fsource',['pps_source',['../structuhd_1_1clock__config__t.html#a934e98b48a62dba3b02d277812452674',1,'uhd::clock_config_t']]]
];
