var searchData=
[
  ['atr_5freg_5ft',['atr_reg_t',['../classuhd_1_1usrp_1_1dboard__iface.html#a7967c68b6067a0a4414c009a4b247c2e',1,'uhd::usrp::dboard_iface']]]
];
