var algorithm_8hpp =
[
    [ "clip", "algorithm_8hpp.html#a6edec8184d2f6d70f59f34d674c57a37", null ],
    [ "has", "algorithm_8hpp.html#a42e26d89ae5d0ad803137f6dd9515581", null ],
    [ "reversed", "algorithm_8hpp.html#aa3e347e55ac33ef685fb9d89a9932099", null ],
    [ "sorted", "algorithm_8hpp.html#a55fd926f7cf639cf297df331e55d0cb0", null ]
];