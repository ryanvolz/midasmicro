var searchData=
[
  ['aux_5fadc_5ft',['aux_adc_t',['../classuhd_1_1usrp_1_1dboard__iface.html#a2a7475c974d1e454311ab88f92b41fa7',1,'uhd::usrp::dboard_iface']]],
  ['aux_5fdac_5ft',['aux_dac_t',['../classuhd_1_1usrp_1_1dboard__iface.html#af2cd3859feb52b75d8a0ab2a13da8720',1,'uhd::usrp::dboard_iface']]]
];
