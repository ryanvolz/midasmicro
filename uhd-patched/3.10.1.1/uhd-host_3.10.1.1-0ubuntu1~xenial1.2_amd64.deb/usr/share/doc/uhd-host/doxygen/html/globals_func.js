var globals_func =
[
    [ "g", "globals_func.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "u", "globals_func_u.html", null ]
];