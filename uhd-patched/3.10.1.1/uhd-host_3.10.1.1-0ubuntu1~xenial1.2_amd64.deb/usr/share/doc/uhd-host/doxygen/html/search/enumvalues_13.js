var searchData=
[
  ['very_5frarely',['very_rarely',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152a00827db86a757c988bd01f9ccba19b53',1,'uhd::_log']]]
];
