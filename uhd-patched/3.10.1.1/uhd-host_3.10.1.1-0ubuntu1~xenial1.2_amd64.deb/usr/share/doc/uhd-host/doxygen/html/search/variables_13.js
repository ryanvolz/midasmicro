var searchData=
[
  ['value',['value',['../structuhd_1_1sensor__value__t.html#ab163cb1b4444129eee10caa26df2d953',1,'uhd::sensor_value_t']]]
];
