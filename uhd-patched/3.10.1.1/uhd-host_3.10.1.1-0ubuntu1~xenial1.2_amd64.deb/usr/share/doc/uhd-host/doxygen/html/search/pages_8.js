var searchData=
[
  ['ni_20rio_20kernel_20modules_20for_20x_2dseries_20pcie_20connectivity',['NI RIO Kernel Modules for X-Series PCIe Connectivity',['../page_ni_rio_kernel.html',1,'page_usrp_x3x0']]]
];
