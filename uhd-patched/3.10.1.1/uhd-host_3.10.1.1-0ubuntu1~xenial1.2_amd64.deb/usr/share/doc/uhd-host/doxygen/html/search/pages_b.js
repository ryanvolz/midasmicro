var searchData=
[
  ['system_20configuration_20for_20usrp_20x3x0_20series',['System Configuration for USRP X3x0 Series',['../page_usrp_x3x0_config.html',1,'page_usrp_x3x0']]]
];
