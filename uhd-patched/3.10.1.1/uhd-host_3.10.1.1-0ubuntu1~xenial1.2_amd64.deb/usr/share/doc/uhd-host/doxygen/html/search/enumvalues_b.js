var searchData=
[
  ['never',['never',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152a88f48c8cc4858df4cb2719f47b1d11a7',1,'uhd::_log']]]
];
