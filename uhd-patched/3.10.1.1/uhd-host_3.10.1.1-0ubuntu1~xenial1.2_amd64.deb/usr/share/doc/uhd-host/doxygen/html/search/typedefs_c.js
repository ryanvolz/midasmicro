var searchData=
[
  ['recv_5fbuffs_5ftype',['recv_buffs_type',['../device__deprecated_8ipp.html#aaec554a8cea48882b29d3e1e121c8e4f',1,'device_deprecated.ipp']]],
  ['row_5ftype',['row_type',['../namespaceuhd_1_1csv.html#a2b95ead2caa46094552ea2e634196ca2',1,'uhd::csv']]],
  ['rows_5ftype',['rows_type',['../namespaceuhd_1_1csv.html#a149943f8f27cfb7d21f60a4e0b202eef',1,'uhd::csv']]]
];
