var searchData=
[
  ['vals',['vals',['../classuhd_1_1dict.html#ac1adc6652fc3c6286122e7a2a8cfc8fd',1,'uhd::dict']]],
  ['value',['value',['../structuhd_1_1sensor__value__t.html#ab163cb1b4444129eee10caa26df2d953',1,'uhd::sensor_value_t']]],
  ['value_5ferror',['value_error',['../structuhd_1_1value__error.html',1,'uhd']]],
  ['value_5ferror',['value_error',['../structuhd_1_1value__error.html#a036f8033b9066bc8f86b5eee82db5a81',1,'uhd::value_error']]],
  ['verbosity_5ft',['verbosity_t',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152',1,'uhd::_log']]],
  ['very_5frarely',['very_rarely',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152a00827db86a757c988bd01f9ccba19b53',1,'uhd::_log']]],
  ['vid_5fpid_5fpair_5ft',['vid_pid_pair_t',['../classuhd_1_1transport_1_1usb__device__handle.html#ae52620333fed7cd947c397859900e5f4',1,'uhd::transport::usb_device_handle']]],
  ['visibility_5ft',['visibility_t',['../classuhd_1_1soft__regmap__t.html#acd62020ff86f205909f396847bbc51ac',1,'uhd::soft_regmap_t']]],
  ['vrt_5fchdr_2edox',['vrt_chdr.dox',['../vrt__chdr_8dox.html',1,'']]],
  ['vrt_5fif_5fpacket_2ehpp',['vrt_if_packet.hpp',['../vrt__if__packet_8hpp.html',1,'']]]
];
