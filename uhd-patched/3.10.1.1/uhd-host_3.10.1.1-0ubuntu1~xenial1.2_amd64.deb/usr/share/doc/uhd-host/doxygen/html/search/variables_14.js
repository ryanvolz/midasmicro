var searchData=
[
  ['width',['width',['../structuhd_1_1otw__type__t.html#a19b746ec4606fb18d236ae2895fee9a7',1,'uhd::otw_type_t']]],
  ['writable',['writable',['../structuhd_1_1usrp_1_1multi__usrp_1_1register__info__t.html#a8d39ad2be06059907d27efc8695360e0',1,'uhd::usrp::multi_usrp::register_info_t::writable()'],['../structuhd__usrp__register__info__t.html#a5414829df356041bfd8414613c4379c4',1,'uhd_usrp_register_info_t::writable()']]]
];
