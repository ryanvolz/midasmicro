var structuhd__usrp__tx__info__t =
[
    [ "mboard_id", "structuhd__usrp__tx__info__t.html#a946066ee9d7140a852a3086cd0bd67b6", null ],
    [ "mboard_name", "structuhd__usrp__tx__info__t.html#aa428598b0a81f274d0804592a505c79d", null ],
    [ "mboard_serial", "structuhd__usrp__tx__info__t.html#afdc693ab454b3a5c0ed8c1a0c0972c83", null ],
    [ "tx_antenna", "structuhd__usrp__tx__info__t.html#aadce92948ea5d4ab5e38627aeb3a428b", null ],
    [ "tx_id", "structuhd__usrp__tx__info__t.html#a1191cde3df0604ccb24ffd21dc08be18", null ],
    [ "tx_serial", "structuhd__usrp__tx__info__t.html#a27b7a6e3786f28f45d21a390c67b17d1", null ],
    [ "tx_subdev_name", "structuhd__usrp__tx__info__t.html#a1f2e9b35c4130ef49879e39822e4ae7d", null ],
    [ "tx_subdev_spec", "structuhd__usrp__tx__info__t.html#ae7a798d398348ee728f9a6c012ec53ec", null ]
];