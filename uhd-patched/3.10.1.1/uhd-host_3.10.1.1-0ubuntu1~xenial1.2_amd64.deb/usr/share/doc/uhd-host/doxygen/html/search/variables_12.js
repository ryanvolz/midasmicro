var searchData=
[
  ['unit',['unit',['../structuhd_1_1sensor__value__t.html#af550ad59bbfc5b0dec07bb0d6748eba7',1,'uhd::sensor_value_t']]],
  ['use_5fcustom_5fdivider',['use_custom_divider',['../structuhd_1_1spi__config__t.html#ab30206773447e593e1b493350719a3bc',1,'uhd::spi_config_t']]],
  ['user_5fpayload',['user_payload',['../structuhd_1_1async__metadata__t.html#a6c9a6d31112ee2ca6439ee8ebc384e4a',1,'uhd::async_metadata_t']]]
];
