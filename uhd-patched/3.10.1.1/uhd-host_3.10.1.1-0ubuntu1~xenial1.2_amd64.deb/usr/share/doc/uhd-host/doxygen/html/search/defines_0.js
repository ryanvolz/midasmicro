var searchData=
[
  ['_5flazymin',['_lazymin',['../device__deprecated_8ipp.html#a0263e65fe0aa04888dff8fdae244dbfd',1,'device_deprecated.ipp']]],
  ['_5fuhd_5fsafe_5fcall_5fwarning',['_UHD_SAFE_CALL_WARNING',['../safe__call_8hpp.html#ab76e0e5df34ac0b780de5596d788ab83',1,'safe_call.hpp']]]
];
