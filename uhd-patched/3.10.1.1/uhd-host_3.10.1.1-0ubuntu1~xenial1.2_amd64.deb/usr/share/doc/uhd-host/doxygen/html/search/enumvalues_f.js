var searchData=
[
  ['rarely',['rarely',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152a694de2de72a61547a379640daa680073',1,'uhd::_log']]],
  ['real',['REAL',['../classuhd_1_1usrp_1_1fe__connection__t.html#aadf0572b3c622e61053ed405327ec61fa725d18ca82a9bec84c0c16fd5bafb755',1,'uhd::usrp::fe_connection_t']]],
  ['realnum',['REALNUM',['../structuhd_1_1sensor__value__t.html#a1f6bf20f81b094c002bf06e3903a37e1a3229a783186316b52f65c25b778b2092',1,'uhd::sensor_value_t']]],
  ['recv_5fmode_5ffull_5fbuff',['RECV_MODE_FULL_BUFF',['../device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2bafa9e13b9690f4d60869674ea9742dbdf56',1,'device_deprecated.ipp']]],
  ['recv_5fmode_5fone_5fpacket',['RECV_MODE_ONE_PACKET',['../device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2bafaa9b332dd69ffc41c347b6d06e57411fd',1,'device_deprecated.ipp']]],
  ['ref_5fauto',['REF_AUTO',['../structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a0cd1a6af945efe76261cfd65205d19ea',1,'uhd::clock_config_t']]],
  ['ref_5fint',['REF_INT',['../structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a9ad0997c6d416fecf103d9dda252c531',1,'uhd::clock_config_t']]],
  ['ref_5fmimo',['REF_MIMO',['../structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a29f14a026c34003ed410ef189d4b8a4e',1,'uhd::clock_config_t']]],
  ['ref_5fsma',['REF_SMA',['../structuhd_1_1clock__config__t.html#ae6775dddf416a20c462a723bc88f55d8a03906cbc61ffb609f69c726241f0014d',1,'uhd::clock_config_t']]],
  ['regularly',['regularly',['../namespaceuhd_1_1__log.html#a8f054e8b8a286e1f5393c2b89dbbe152add9505c0a595fe73f0dd7e2d9045bd28',1,'uhd::_log']]],
  ['rx_5fdirection',['RX_DIRECTION',['../namespaceuhd.html#a15fbb7809a271ea929ea2390624eb425a5d8193bc8201b25945aaa4b02c6b9bf1',1,'uhd']]]
];
