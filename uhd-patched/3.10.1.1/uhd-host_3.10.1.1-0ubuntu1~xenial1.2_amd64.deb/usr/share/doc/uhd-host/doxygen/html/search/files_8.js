var searchData=
[
  ['log_2ehpp',['log.hpp',['../log_8hpp.html',1,'']]]
];
