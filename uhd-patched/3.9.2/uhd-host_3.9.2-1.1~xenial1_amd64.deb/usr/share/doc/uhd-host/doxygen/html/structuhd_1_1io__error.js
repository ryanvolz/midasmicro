var structuhd_1_1io__error =
[
    [ "io_error", "structuhd_1_1io__error.html#a195efe9e853751a6125167f375cbc608", null ],
    [ "code", "structuhd_1_1io__error.html#a765fe8d7a8980993ee9408ffae017c01", null ],
    [ "dynamic_clone", "structuhd_1_1io__error.html#a0dd24fb9291bdd413ddb9bcea74952e8", null ],
    [ "dynamic_throw", "structuhd_1_1io__error.html#a8ade0c6e413643fb2a93d2cce17838b4", null ]
];