var device__deprecated_8ipp =
[
    [ "_lazymin", "device__deprecated_8ipp.html#a0263e65fe0aa04888dff8fdae244dbfd", null ],
    [ "recv_buffs_type", "device__deprecated_8ipp.html#aaec554a8cea48882b29d3e1e121c8e4f", null ],
    [ "send_buffs_type", "device__deprecated_8ipp.html#aa306787f4ac84113e7081912bdd2fcfc", null ],
    [ "recv_mode_t", "device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2baf", [
      [ "RECV_MODE_FULL_BUFF", "device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2bafa9e13b9690f4d60869674ea9742dbdf56", null ],
      [ "RECV_MODE_ONE_PACKET", "device__deprecated_8ipp.html#a78035a64d541196e4c8e8db511df2bafaa9b332dd69ffc41c347b6d06e57411fd", null ]
    ] ],
    [ "send_mode_t", "device__deprecated_8ipp.html#ae952a83b7868c74e272789e347e92b58", [
      [ "SEND_MODE_FULL_BUFF", "device__deprecated_8ipp.html#ae952a83b7868c74e272789e347e92b58a0d4108ad751d15ae5bc51cbc934deb07", null ],
      [ "SEND_MODE_ONE_PACKET", "device__deprecated_8ipp.html#ae952a83b7868c74e272789e347e92b58a0233b3d5533375c566fba28ebcb29e81", null ]
    ] ],
    [ "get_max_recv_samps_per_packet", "device__deprecated_8ipp.html#a63c83ccf50c88b380b53d71bcb315bba", null ],
    [ "get_max_send_samps_per_packet", "device__deprecated_8ipp.html#a1502c9c25bfe8eef059b74b31a1ed99b", null ],
    [ "recv", "device__deprecated_8ipp.html#a68481f09d04c904df86751a0c13f0dd2", null ],
    [ "recv_async_msg", "device__deprecated_8ipp.html#a0ddbb1f999b4d703fa6030a141c73e44", null ],
    [ "send", "device__deprecated_8ipp.html#abae30e7593a958c3202d4d0afed42b58", null ],
    [ "_recv_tid", "device__deprecated_8ipp.html#a9f8f616fd0ac66641b5b4beae4063177", null ],
    [ "_rx_streamer", "device__deprecated_8ipp.html#ac7910356d810c3e3e5845fce1849eaac", null ],
    [ "_send_tid", "device__deprecated_8ipp.html#aae936d6633f666ed631d6e021041c5ca", null ],
    [ "_tx_streamer", "device__deprecated_8ipp.html#ac9ef4414af4cf26fd774bf4023570155", null ]
];