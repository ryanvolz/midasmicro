var structuhd_1_1usrp_1_1subdev__spec__pair__t =
[
    [ "subdev_spec_pair_t", "structuhd_1_1usrp_1_1subdev__spec__pair__t.html#a2bae39baaf529834fbd719cbd79e4a01", null ],
    [ "db_name", "structuhd_1_1usrp_1_1subdev__spec__pair__t.html#ad49c2e1a14892c3dadccd2bd74908bae", null ],
    [ "sd_name", "structuhd_1_1usrp_1_1subdev__spec__pair__t.html#a2446ca125e631b7c7fd9171ba7383067", null ]
];