var structuhd_1_1image__loader_1_1image__loader__args__t =
[
    [ "args", "structuhd_1_1image__loader_1_1image__loader__args__t.html#a01f51464444fdd4715ee1fd3fa9faf55", null ],
    [ "firmware_path", "structuhd_1_1image__loader_1_1image__loader__args__t.html#ac6e992e74fcfcceb3dd67790614f4bd4", null ],
    [ "fpga_path", "structuhd_1_1image__loader_1_1image__loader__args__t.html#aafd3ab71283b25ad991b293741166d9b", null ],
    [ "load_firmware", "structuhd_1_1image__loader_1_1image__loader__args__t.html#a2fbb88a5a31734f215cbdc77d35fd60f", null ],
    [ "load_fpga", "structuhd_1_1image__loader_1_1image__loader__args__t.html#a177f1638ca74811cdde797ad6ed3c00b", null ]
];