var structuhd_1_1usb__error =
[
    [ "usb_error", "structuhd_1_1usb__error.html#ae5f811daf1aeba0c273f37217306430b", null ],
    [ "code", "structuhd_1_1usb__error.html#afd2115d71cf10c2f333f7d4e40fd28a7", null ],
    [ "dynamic_clone", "structuhd_1_1usb__error.html#a2360bee020e9443f564e14a1551a9a5d", null ],
    [ "dynamic_throw", "structuhd_1_1usb__error.html#ac08ddb57a8ad35b67bfb0e3dcd86ee08", null ],
    [ "_code", "structuhd_1_1usb__error.html#a77a83d432228154b9609e5ffb534fdee", null ]
];