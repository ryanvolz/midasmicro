var bounded__buffer_8ipp =
[
    [ "bounded_buffer_detail", "classuhd_1_1transport_1_1bounded__buffer__detail.html", "classuhd_1_1transport_1_1bounded__buffer__detail" ],
    [ "INCLUDED_UHD_TRANSPORT_BOUNDED_BUFFER_IPP", "bounded__buffer_8ipp.html#ac1450eee4f49105d4b9e0eee6dcd7ba9", null ]
];