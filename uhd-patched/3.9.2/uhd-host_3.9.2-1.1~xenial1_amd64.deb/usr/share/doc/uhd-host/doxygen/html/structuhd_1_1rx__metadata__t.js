var structuhd_1_1rx__metadata__t =
[
    [ "error_code_t", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639", [
      [ "ERROR_CODE_NONE", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a30c16ffa6113fbbaca9246fb7e1e9175", null ],
      [ "ERROR_CODE_TIMEOUT", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a64632eaf9b5ebdabe94f623bb4017c9b", null ],
      [ "ERROR_CODE_LATE_COMMAND", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a117bc72e437060564a5f03b8a9856e88", null ],
      [ "ERROR_CODE_BROKEN_CHAIN", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a1a0c6c210cac5dd454ff6eda10524969", null ],
      [ "ERROR_CODE_OVERFLOW", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639af52d18388ea782e474b134bb3bace485", null ],
      [ "ERROR_CODE_ALIGNMENT", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a1b2dd7d72f764f3071e362fe566e0011", null ],
      [ "ERROR_CODE_BAD_PACKET", "structuhd_1_1rx__metadata__t.html#ae3a42ad2414c4f44119157693fe27639a56ed4063c6f6e1e23ddea5cadf2b807c", null ]
    ] ],
    [ "rx_metadata_t", "structuhd_1_1rx__metadata__t.html#a0e376e976185ad4deaf039a5dd9df6f5", null ],
    [ "reset", "structuhd_1_1rx__metadata__t.html#a96dee4e7287c55c0b6c59217c6e4f2e4", null ],
    [ "strerror", "structuhd_1_1rx__metadata__t.html#a0a033cef5cc266551cd719e2d233d9c2", null ],
    [ "to_pp_string", "structuhd_1_1rx__metadata__t.html#aec9a516f0a33bdd0743c6f049030456a", null ],
    [ "end_of_burst", "structuhd_1_1rx__metadata__t.html#a69e306add401a7e0a0caa5e30d6ee5ce", null ],
    [ "error_code", "structuhd_1_1rx__metadata__t.html#ab0a70db215d88d013c6b71e132ac3b54", null ],
    [ "fragment_offset", "structuhd_1_1rx__metadata__t.html#aec8f2278ac684af1ca3ac22ddec668ca", null ],
    [ "has_time_spec", "structuhd_1_1rx__metadata__t.html#a7cd978c6290c12f3bb92072286109123", null ],
    [ "more_fragments", "structuhd_1_1rx__metadata__t.html#a10b3fe1655a605bac6b5a07e7c8fe4f4", null ],
    [ "out_of_sequence", "structuhd_1_1rx__metadata__t.html#a1bd09159cf5f2109cfa168758213ddee", null ],
    [ "start_of_burst", "structuhd_1_1rx__metadata__t.html#ac36a6c9889ccbac4999496e3681eb088", null ],
    [ "time_spec", "structuhd_1_1rx__metadata__t.html#a14daac3e0c3a4d2b074962bf2d795b81", null ]
];