var structuhd_1_1not__implemented__error =
[
    [ "not_implemented_error", "structuhd_1_1not__implemented__error.html#a1208058ad1f5fc687ba771df47b61e4e", null ],
    [ "code", "structuhd_1_1not__implemented__error.html#a5c81809a55695b232f244c7ae65f1d67", null ],
    [ "dynamic_clone", "structuhd_1_1not__implemented__error.html#a06f96136082726359e10ba4c1c002c56", null ],
    [ "dynamic_throw", "structuhd_1_1not__implemented__error.html#adc2e8585e4ecb319d9975ad3b68dc506", null ]
];