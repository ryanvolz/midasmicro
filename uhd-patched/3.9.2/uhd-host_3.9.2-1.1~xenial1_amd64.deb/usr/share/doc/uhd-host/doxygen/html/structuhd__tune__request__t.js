var structuhd__tune__request__t =
[
    [ "args", "structuhd__tune__request__t.html#a858c24b6165cf396c7a09147f6075933", null ],
    [ "dsp_freq", "structuhd__tune__request__t.html#a4ec2f1725cde3ff303c0a758df21000d", null ],
    [ "dsp_freq_policy", "structuhd__tune__request__t.html#a1bf66d6d89470a64f6859e692a49f8fb", null ],
    [ "rf_freq", "structuhd__tune__request__t.html#a3e43dee534717535fcd446bbf84ad504", null ],
    [ "rf_freq_policy", "structuhd__tune__request__t.html#ad0886b163d96e0daea21be2245fbf1e8", null ],
    [ "target_freq", "structuhd__tune__request__t.html#a98bd1726162a3fcffe8d1e029d69af78", null ]
];