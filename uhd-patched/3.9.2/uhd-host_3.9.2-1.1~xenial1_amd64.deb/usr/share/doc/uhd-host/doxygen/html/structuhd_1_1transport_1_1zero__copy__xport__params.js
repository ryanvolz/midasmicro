var structuhd_1_1transport_1_1zero__copy__xport__params =
[
    [ "num_recv_frames", "structuhd_1_1transport_1_1zero__copy__xport__params.html#a05832937ccd7aabc891f331a2fd4b915", null ],
    [ "num_send_frames", "structuhd_1_1transport_1_1zero__copy__xport__params.html#a6dee1be80a77e669929cc3136d679d84", null ],
    [ "recv_frame_size", "structuhd_1_1transport_1_1zero__copy__xport__params.html#a16fb4cf4bb36e46224d6df81697668cb", null ],
    [ "send_frame_size", "structuhd_1_1transport_1_1zero__copy__xport__params.html#a31d6a719fdf042593c38de4d1b4e38bc", null ]
];