var msg_8hpp =
[
    [ "_msg", "classuhd_1_1msg_1_1__msg.html", "classuhd_1_1msg_1_1__msg" ],
    [ "UHD_HERE", "msg_8hpp.html#a0ec718025802d29e8ed78a66e9a1908a", null ],
    [ "UHD_HEX", "msg_8hpp.html#a98e566c4d02f4b4a6f7d4c7f5385b7de", null ],
    [ "UHD_MSG", "msg_8hpp.html#ab71fc642612b85370d18b6e35f5fed15", null ],
    [ "UHD_VAR", "msg_8hpp.html#a8439acc29dcd403f77b8a021f5c64f07", null ],
    [ "handler_t", "msg_8hpp.html#ab996daa918cb261547615ea33b618ba1", null ],
    [ "type_t", "msg_8hpp.html#a39e78d22a268a4f0375423a1d588139b", [
      [ "status", "msg_8hpp.html#a39e78d22a268a4f0375423a1d588139ba4a6791e1c064188a13d6a802e0fe073a", null ],
      [ "warning", "msg_8hpp.html#a39e78d22a268a4f0375423a1d588139baeece253580978ed29753e248e36ca44b", null ],
      [ "error", "msg_8hpp.html#a39e78d22a268a4f0375423a1d588139ba51300d826692a9c1b6e846aed789e3a6", null ],
      [ "fastpath", "msg_8hpp.html#a39e78d22a268a4f0375423a1d588139ba6747ccde4b852b6baf912a96e4c90f4c", null ]
    ] ],
    [ "register_handler", "msg_8hpp.html#aa5380a801e1ac6b8a35aa95543fc3e8e", null ]
];