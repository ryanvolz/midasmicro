var classuhd_1_1spi__iface =
[
    [ "sptr", "classuhd_1_1spi__iface.html#a5c449b4d49d7d0bb616d6d840eda403f", null ],
    [ "~spi_iface", "classuhd_1_1spi__iface.html#a5bf64a423056fdbf68b4f2450fc23527", null ],
    [ "read_spi", "classuhd_1_1spi__iface.html#afb4374ac666a4db6e8c3ede07a2f61a3", null ],
    [ "transact_spi", "classuhd_1_1spi__iface.html#acd38a61ccfb059cbe554c1cecc7a9c17", null ],
    [ "write_spi", "classuhd_1_1spi__iface.html#a7203e52487d0493b3305e2bf45cbc88c", null ]
];