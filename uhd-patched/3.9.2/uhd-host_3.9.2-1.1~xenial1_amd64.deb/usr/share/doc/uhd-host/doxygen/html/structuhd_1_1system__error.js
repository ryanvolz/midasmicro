var structuhd_1_1system__error =
[
    [ "system_error", "structuhd_1_1system__error.html#a55311eb0a7f3af67503eb76b301be162", null ],
    [ "code", "structuhd_1_1system__error.html#a455063fd81c172d12498390fd3b4ef24", null ],
    [ "dynamic_clone", "structuhd_1_1system__error.html#a7991ca0e0746aaa024313605a873101a", null ],
    [ "dynamic_throw", "structuhd_1_1system__error.html#a8e5e445ce6f8f6a5f5eb008f6aa24022", null ]
];