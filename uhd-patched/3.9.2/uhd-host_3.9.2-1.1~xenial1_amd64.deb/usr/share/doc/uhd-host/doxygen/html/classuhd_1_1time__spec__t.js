var classuhd_1_1time__spec__t =
[
    [ "time_spec_t", "classuhd_1_1time__spec__t.html#a2bd6c4c8ad7209d219c3ca5ae238fb6e", null ],
    [ "time_spec_t", "classuhd_1_1time__spec__t.html#a37e2cc38aa479200989cd3c7c1e4814b", null ],
    [ "time_spec_t", "classuhd_1_1time__spec__t.html#a8c8aee70db00810c0914fab28dfdc645", null ],
    [ "get_frac_secs", "classuhd_1_1time__spec__t.html#a76bb46c8415285383ca89786253e32ed", null ],
    [ "get_full_secs", "classuhd_1_1time__spec__t.html#a6226790aa8374389cde058fd7d87d05c", null ],
    [ "get_real_secs", "classuhd_1_1time__spec__t.html#a08111dd74652ddf9d209344fd0fb9cf9", null ],
    [ "get_tick_count", "classuhd_1_1time__spec__t.html#a7477bd07cb0ebe4b0c3aee94f84aa3f0", null ],
    [ "operator+=", "classuhd_1_1time__spec__t.html#aee41ca079ce9d090c801c0ce08dd2c36", null ],
    [ "operator-=", "classuhd_1_1time__spec__t.html#af0a274e20c8576ac8e5b1b2cbf0982d6", null ],
    [ "to_ticks", "classuhd_1_1time__spec__t.html#ad75960ba4c788cd30a5d0c8904888da3", null ]
];