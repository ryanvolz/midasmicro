var classuhd_1_1soft__register__t =
[
    [ "sptr", "classuhd_1_1soft__register__t.html#a11be6bb5e94c0f58223496f41db6ff48", null ],
    [ "soft_register_t", "classuhd_1_1soft__register__t.html#a9faf5a03cb4c2922257f7352ededa499", null ],
    [ "soft_register_t", "classuhd_1_1soft__register__t.html#a183d25d18d91af393c3ce54d405516f0", null ],
    [ "flush", "classuhd_1_1soft__register__t.html#a6aa64d7c7ec7dac06845499ff62d3cfd", null ],
    [ "get", "classuhd_1_1soft__register__t.html#a303b236ca48898b937b193289316c735", null ],
    [ "get_bitwidth", "classuhd_1_1soft__register__t.html#a42167935121a98e7fb7c69e30e17fa1a", null ],
    [ "initialize", "classuhd_1_1soft__register__t.html#a04a9a8aa8bc15775f6096858844b3e8f", null ],
    [ "is_readable", "classuhd_1_1soft__register__t.html#abbffd2d937920a90af1e24f285fdeff4", null ],
    [ "is_writable", "classuhd_1_1soft__register__t.html#a0613fdfb2c00c1b19fcff12ef22d0bd6", null ],
    [ "read", "classuhd_1_1soft__register__t.html#aced2fe78d7d7f843a57ef4567bb53031", null ],
    [ "refresh", "classuhd_1_1soft__register__t.html#a763b4bf673f27752852bccd3742c1b9e", null ],
    [ "set", "classuhd_1_1soft__register__t.html#a7dbdaf1861df07914ee99f2dbbae2e3e", null ],
    [ "write", "classuhd_1_1soft__register__t.html#a657a1a01c0f3ad5d14886454dbe7e915", null ]
];