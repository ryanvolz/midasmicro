var structuhd_1_1usrp_1_1dboard__iface__special__props__t =
[
    [ "mangle_i2c_addrs", "structuhd_1_1usrp_1_1dboard__iface__special__props__t.html#a5bef14be2189e97c69c94902dc49c831", null ],
    [ "soft_clock_divider", "structuhd_1_1usrp_1_1dboard__iface__special__props__t.html#a9a9bce30eeff1d7966173834346d3fd1", null ]
];