var classuhd_1_1transport_1_1udp__zero__copy =
[
    [ "buff_params", "structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params.html", "structuhd_1_1transport_1_1udp__zero__copy_1_1buff__params" ],
    [ "sptr", "classuhd_1_1transport_1_1udp__zero__copy.html#a59744845d9823ec8aa2953b0377fe0e8", null ]
];