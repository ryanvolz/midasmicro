var classuhd_1_1i2c__iface =
[
    [ "sptr", "classuhd_1_1i2c__iface.html#a65140bfd1527b10f13cb1e5a37f3a3e9", null ],
    [ "~i2c_iface", "classuhd_1_1i2c__iface.html#a9c84f3853f743914395e7036f940d6f0", null ],
    [ "eeprom16", "classuhd_1_1i2c__iface.html#abb67ce0ae3254672299cc6b1333e7643", null ],
    [ "read_eeprom", "classuhd_1_1i2c__iface.html#afc006c74f60aecbbcfbe099f44cc257c", null ],
    [ "read_i2c", "classuhd_1_1i2c__iface.html#a842bbd12a36944ab535d261de4c7351f", null ],
    [ "write_eeprom", "classuhd_1_1i2c__iface.html#abba85e1ebfb81b9f97c3fa48b3c90d05", null ],
    [ "write_i2c", "classuhd_1_1i2c__iface.html#a7bfa577ef3bb00b23e0f5a75f8f0eb02", null ]
];