var structuhd_1_1value__error =
[
    [ "value_error", "structuhd_1_1value__error.html#a036f8033b9066bc8f86b5eee82db5a81", null ],
    [ "code", "structuhd_1_1value__error.html#a90ab0d3fdae1b3ed48bef6a6892d6bfd", null ],
    [ "dynamic_clone", "structuhd_1_1value__error.html#aa8973d9efa61e44f696906b8c1466b8a", null ],
    [ "dynamic_throw", "structuhd_1_1value__error.html#a35a232b81c1a461900083c3b8d538278", null ]
];