var classuhd_1_1gps__ctrl =
[
    [ "sptr", "classuhd_1_1gps__ctrl.html#ac96f09206d283ddc66b378e0d66f14a4", null ],
    [ "~gps_ctrl", "classuhd_1_1gps__ctrl.html#ae11de47e0143d99f354ae3f89eca93e9", null ],
    [ "get_sensor", "classuhd_1_1gps__ctrl.html#aaa2e8f6f0919d0f7e7a8aaa2c85cf02c", null ],
    [ "get_sensors", "classuhd_1_1gps__ctrl.html#a0adaa260cc2f6ac13f7ed530a819f170", null ],
    [ "gps_detected", "classuhd_1_1gps__ctrl.html#ad1ce057e0eabdc90e50aa294c9055568", null ]
];