var structuhd__stream__args__t =
[
    [ "args", "structuhd__stream__args__t.html#af6a465011ce9b156ec720df77b92af54", null ],
    [ "channel_list", "structuhd__stream__args__t.html#aba4933e6c75e28e9c267f089c7f7bd96", null ],
    [ "cpu_format", "structuhd__stream__args__t.html#a22234f7a37ff543b99f88293146452d1", null ],
    [ "n_channels", "structuhd__stream__args__t.html#a5bde43c4ca7f50431861453a0cb45241", null ],
    [ "otw_format", "structuhd__stream__args__t.html#a06719a92d67f3c57307ed4c7b704b735", null ]
];