var structuhd_1_1os__error =
[
    [ "os_error", "structuhd_1_1os__error.html#ae5b0f2f63127b1bb403eb7c619622f49", null ],
    [ "code", "structuhd_1_1os__error.html#a38d24c26c79fbb35f6db4591b2c32e05", null ],
    [ "dynamic_clone", "structuhd_1_1os__error.html#a58fc0ee4d94219fee9e3f3e6d9b1060a", null ],
    [ "dynamic_throw", "structuhd_1_1os__error.html#a7ae75865c7a5921cce6d0b204c77bf80", null ]
];