var structuhd_1_1index__error =
[
    [ "index_error", "structuhd_1_1index__error.html#a8fd30a3bab92b24ae4939523fa8967df", null ],
    [ "code", "structuhd_1_1index__error.html#a90ad3bc08bc09a18dfd6e1ce3ffb5ae3", null ],
    [ "dynamic_clone", "structuhd_1_1index__error.html#aed13d0e0d3ab73fc6d0944a898b87061", null ],
    [ "dynamic_throw", "structuhd_1_1index__error.html#a3257ef588d1b4e58e69467947edc22e4", null ]
];