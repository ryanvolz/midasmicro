var namespaceuhd_1_1math_1_1fp__compare =
[
    [ "fp_compare_delta", "classuhd_1_1math_1_1fp__compare_1_1fp__compare__delta.html", "classuhd_1_1math_1_1fp__compare_1_1fp__compare__delta" ],
    [ "fp_compare_epsilon", "classuhd_1_1math_1_1fp__compare_1_1fp__compare__epsilon.html", "classuhd_1_1math_1_1fp__compare_1_1fp__compare__epsilon" ]
];