var structuhd_1_1assertion__error =
[
    [ "assertion_error", "structuhd_1_1assertion__error.html#a73690cc3a03931c8b32daf15a9bc6400", null ],
    [ "code", "structuhd_1_1assertion__error.html#aa4a9d8bb56a21fae6c466fc469654a74", null ],
    [ "dynamic_clone", "structuhd_1_1assertion__error.html#a7479b10ee7095f6e3d719b1b6aa0e95c", null ],
    [ "dynamic_throw", "structuhd_1_1assertion__error.html#a30beab5e2a91d7f0e775adce8bf8fa99", null ]
];