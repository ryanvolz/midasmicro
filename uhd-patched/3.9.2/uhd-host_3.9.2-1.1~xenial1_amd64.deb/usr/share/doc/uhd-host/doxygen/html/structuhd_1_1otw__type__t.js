var structuhd_1_1otw__type__t =
[
    [ "BO_NATIVE", "structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983af2dc214b6aef4ba3caa49b18041867b6", null ],
    [ "BO_LITTLE_ENDIAN", "structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983a0c2f7178dbea0ef02c45bae7a1d8d646", null ],
    [ "BO_BIG_ENDIAN", "structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983a5c9d721ec8edfb899b1704cd70904be4", null ],
    [ "BO_NOT_APPLICABLE", "structuhd_1_1otw__type__t.html#a3e813d310c7c73335620010ee9648983aa26e4bff795c8269b2db19aa887c2b4c", null ],
    [ "otw_type_t", "structuhd_1_1otw__type__t.html#a58457911e05dd159703eec1f56ac2e1d", null ],
    [ "get_sample_size", "structuhd_1_1otw__type__t.html#a037d455f5f07ac64502a185c2ddb3733", null ],
    [ "byteorder", "structuhd_1_1otw__type__t.html#a8d9ea1457c64ae68b3db89be5a5288a4", null ],
    [ "shift", "structuhd_1_1otw__type__t.html#a7b0f8811f074ad61198655e5fa903144", null ],
    [ "width", "structuhd_1_1otw__type__t.html#a19b746ec4606fb18d236ae2895fee9a7", null ]
];