var structuhd_1_1transport_1_1vrt_1_1if__packet__info__t =
[
    [ "link_type_t", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a0582bd0a23b0f359185644ab6f431755", [
      [ "LINK_TYPE_NONE", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a0582bd0a23b0f359185644ab6f431755ad4dbc799ee7f79403a992caf03320498", null ],
      [ "LINK_TYPE_CHDR", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a0582bd0a23b0f359185644ab6f431755ac2de300441c2037edd176ef83f429261", null ],
      [ "LINK_TYPE_VRLP", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a0582bd0a23b0f359185644ab6f431755a7e714ee818dbc4440ce03f66f12a9e23", null ]
    ] ],
    [ "packet_type_t", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7d", [
      [ "PACKET_TYPE_DATA", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7dabbe3763040597c11af66d1d415df8529", null ],
      [ "PACKET_TYPE_IF_EXT", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7daa8ec1539e47d08d1be2fd53b3a2fabfb", null ],
      [ "PACKET_TYPE_CONTEXT", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7da14297e47ba63c41a2665993263d93e4d", null ],
      [ "PACKET_TYPE_FC", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7dafb0f264649ac78e4db13b75a8275c4fe", null ],
      [ "PACKET_TYPE_ACK", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7dac6cd4fcd51848d799117bca860869283", null ],
      [ "PACKET_TYPE_CMD", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7da3323c0973ad5d32cb26289c0f87d09ef", null ],
      [ "PACKET_TYPE_RESP", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7dab4d168206bac0fc8c63bf7d1dad64d17", null ],
      [ "PACKET_TYPE_ERROR", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a883c99156bcf6eaf497da93cfba91b7da6dd1bfffc127947a4b81962c1fb1a3c9", null ]
    ] ],
    [ "if_packet_info_t", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a4225728b77ca303aae48efc2a61823d0", null ],
    [ "cid", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a302a43eb29f41c88f6d7beb4af7e8ef6", null ],
    [ "eob", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a6873bfffa90438a78307045d29191660", null ],
    [ "error", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#aff48430515718b7e075f49921529edad", null ],
    [ "has_cid", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#abf03386fd2cfaa59b3948645ad9ceb36", null ],
    [ "has_sid", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a8415dcafcf5b32750a757b5b15424aad", null ],
    [ "has_tlr", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#aae2d1fc554402f5eda38879578af0add", null ],
    [ "has_tsf", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a05620235be16ac3b9ad1eaf0864d6627", null ],
    [ "has_tsi", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a9dcd8f46d3f39627945dd9d429fec8a3", null ],
    [ "link_type", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a6353f1fe270e5bd4481a2ea5beaea3ca", null ],
    [ "num_header_words32", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#aff387148e3f0d739f09816776bc06176", null ],
    [ "num_packet_words32", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a734aa3e8bdc9db176c0f52b0b66132d3", null ],
    [ "num_payload_bytes", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a708b649b3cb7c54cde707b93a31caca8", null ],
    [ "num_payload_words32", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#ae9b8baf85d44c7b91a6b27d139f5b1d8", null ],
    [ "packet_count", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a87ced31ed311ba8c4bd6113844d64abf", null ],
    [ "packet_type", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a9e761f9501aa6f7a5f8034e12c5453e6", null ],
    [ "sid", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a8ab298f6597b8a2fbcc7e06b732061c0", null ],
    [ "sob", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a5f63fc4d646221211758f8a611be2202", null ],
    [ "tlr", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a673c21fe50e7095363a956cfeeba0101", null ],
    [ "tsf", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#a935999da982a764e7639062ef50fdd4a", null ],
    [ "tsi", "structuhd_1_1transport_1_1vrt_1_1if__packet__info__t.html#ae3ac2895b30c5cd99b43fe8df8792b7a", null ]
];