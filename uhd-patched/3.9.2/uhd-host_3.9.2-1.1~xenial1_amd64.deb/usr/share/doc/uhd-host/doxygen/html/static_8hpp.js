var static_8hpp =
[
    [ "_uhd_static_fixture", "struct__uhd__static__fixture.html", "struct__uhd__static__fixture" ],
    [ "UHD_SINGLETON_FCN", "static_8hpp.html#ad3a6fc9d7285fb128e83d8e0b55fee38", null ],
    [ "UHD_STATIC_BLOCK", "static_8hpp.html#a35dca02aa6a2a694cb9433a6e7fe6016", null ]
];