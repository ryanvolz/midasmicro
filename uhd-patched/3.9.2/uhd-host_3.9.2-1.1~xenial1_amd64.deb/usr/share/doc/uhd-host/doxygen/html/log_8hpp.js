var log_8hpp =
[
    [ "log", "classuhd_1_1__log_1_1log.html", "classuhd_1_1__log_1_1log" ],
    [ "INSERTION_OVERLOAD", "log_8hpp.html#a38bc05b10aa00462f5a772586f5d964e", null ],
    [ "UHD_LOG", "log_8hpp.html#a59b713f074ecaff20738b3b4aad2c21b", null ],
    [ "UHD_LOGV", "log_8hpp.html#a8991fb84b1de5fb137e40a8074a3d0a0", null ],
    [ "verbosity_t", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152", [
      [ "always", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152a1d75866c938e0f6af59e84b4592f5632", null ],
      [ "often", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152ab1f6c4fa1130442b882d7924191f5955", null ],
      [ "regularly", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152add9505c0a595fe73f0dd7e2d9045bd28", null ],
      [ "rarely", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152a694de2de72a61547a379640daa680073", null ],
      [ "very_rarely", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152a00827db86a757c988bd01f9ccba19b53", null ],
      [ "never", "log_8hpp.html#a8f054e8b8a286e1f5393c2b89dbbe152a88f48c8cc4858df4cb2719f47b1d11a7", null ]
    ] ]
];