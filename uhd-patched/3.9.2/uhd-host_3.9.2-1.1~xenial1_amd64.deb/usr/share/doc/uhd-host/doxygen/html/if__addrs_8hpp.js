var if__addrs_8hpp =
[
    [ "if_addrs_t", "structuhd_1_1transport_1_1if__addrs__t.html", "structuhd_1_1transport_1_1if__addrs__t" ],
    [ "get_if_addrs", "if__addrs_8hpp.html#a838d24454a5e6119a97d74374e935854", null ]
];