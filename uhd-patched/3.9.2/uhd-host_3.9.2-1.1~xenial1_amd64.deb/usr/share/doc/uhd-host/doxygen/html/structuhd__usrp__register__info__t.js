var structuhd__usrp__register__info__t =
[
    [ "bitwidth", "structuhd__usrp__register__info__t.html#ac41c902e2b6c57bcfc59c7765e5adfbb", null ],
    [ "readable", "structuhd__usrp__register__info__t.html#af151005503064ae5048927204f340034", null ],
    [ "writable", "structuhd__usrp__register__info__t.html#a5414829df356041bfd8414613c4379c4", null ]
];