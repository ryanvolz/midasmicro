var zero__copy_8hpp =
[
    [ "managed_buffer", "classuhd_1_1transport_1_1managed__buffer.html", "classuhd_1_1transport_1_1managed__buffer" ],
    [ "managed_recv_buffer", "classuhd_1_1transport_1_1managed__recv__buffer.html", "classuhd_1_1transport_1_1managed__recv__buffer" ],
    [ "managed_send_buffer", "classuhd_1_1transport_1_1managed__send__buffer.html", "classuhd_1_1transport_1_1managed__send__buffer" ],
    [ "zero_copy_xport_params", "structuhd_1_1transport_1_1zero__copy__xport__params.html", "structuhd_1_1transport_1_1zero__copy__xport__params" ],
    [ "zero_copy_if", "classuhd_1_1transport_1_1zero__copy__if.html", "classuhd_1_1transport_1_1zero__copy__if" ],
    [ "intrusive_ptr_add_ref", "zero__copy_8hpp.html#a00d41dc37684e3dde7e0dda35995de49", null ],
    [ "intrusive_ptr_release", "zero__copy_8hpp.html#afff62a1607ce569c3a32e88777b2df0a", null ]
];