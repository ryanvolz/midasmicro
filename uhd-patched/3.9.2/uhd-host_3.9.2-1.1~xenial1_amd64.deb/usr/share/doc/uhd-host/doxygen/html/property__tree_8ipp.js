var property__tree_8ipp =
[
    [ "INCLUDED_UHD_PROPERTY_TREE_IPP", "property__tree_8ipp.html#a10cd9e34517677cf1b22443ffca077ac", null ],
    [ "_coercer", "property__tree_8ipp.html#a7adb6718e21604b025140314388d912e", null ],
    [ "_publisher", "property__tree_8ipp.html#a86b76730e9f9f9ec3e1e1c9afc41ba26", null ],
    [ "_subscribers", "property__tree_8ipp.html#ae2bcb1c4d76710959d52f9116fc2fb15", null ],
    [ "_value", "property__tree_8ipp.html#a69b97cd387c73ac7b15bbbaee68b40ce", null ]
];