var structuhd_1_1transport_1_1if__addrs__t =
[
    [ "bcast", "structuhd_1_1transport_1_1if__addrs__t.html#af5211dfae676fe6ec5b0fb7378f43968", null ],
    [ "inet", "structuhd_1_1transport_1_1if__addrs__t.html#a453185c1ab724733f9fb3dbdc03a64bc", null ],
    [ "mask", "structuhd_1_1transport_1_1if__addrs__t.html#af08a5933203c43c84bc17006c93307e2", null ]
];