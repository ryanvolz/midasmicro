var classuhd_1_1image__loader =
[
    [ "image_loader_args_t", "structuhd_1_1image__loader_1_1image__loader__args__t.html", "structuhd_1_1image__loader_1_1image__loader__args__t" ],
    [ "loader_fcn_t", "classuhd_1_1image__loader.html#adb27aa4abf139ba9e4bc5f7821ede1c9", null ]
];