var structuhd_1_1usrp_1_1dboard__eeprom__t =
[
    [ "dboard_eeprom_t", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#a6f301fab2fdc542666fab774998ebf43", null ],
    [ "load", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#a730b506d58328c0e9c4c45f5c0919403", null ],
    [ "store", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#aff1f17f8032eb75d0c0d0bed164d688c", null ],
    [ "id", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#a2fff2ce6843bd23ebb9c474b00561d05", null ],
    [ "revision", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#a28f9c91fc3f1c521dc0db48f7c6c64d1", null ],
    [ "serial", "structuhd_1_1usrp_1_1dboard__eeprom__t.html#ac41565ca47b70c83565f91c8b2a389c0", null ]
];