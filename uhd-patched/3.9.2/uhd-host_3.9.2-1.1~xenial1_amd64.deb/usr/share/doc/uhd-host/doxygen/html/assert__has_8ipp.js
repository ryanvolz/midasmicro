var assert__has_8ipp =
[
    [ "INCLUDED_UHD_UTILS_ASSERT_HAS_IPP", "assert__has_8ipp.html#aa5c1011eb5c544b72ba8c4c7dd5815dd", null ],
    [ "assert_has", "assert__has_8ipp.html#a6ea1a6336a5ee0168e30a76af6a807e1", null ]
];