var sensors_8h =
[
    [ "uhd_sensor_value_handle", "sensors_8h.html#aeb03cca2394aaacbb1766e42ced78b13", null ],
    [ "uhd_sensor_value_data_type_t", "sensors_8h.html#acc485fe487df83f53d5646640b3a5b74", [
      [ "UHD_SENSOR_VALUE_BOOLEAN", "sensors_8h.html#acc485fe487df83f53d5646640b3a5b74a78c5d2b691a8eacae0bfdd0f44b992a2", null ],
      [ "UHD_SENSOR_VALUE_INTEGER", "sensors_8h.html#acc485fe487df83f53d5646640b3a5b74af4c33fa917ca6254d14ad93e3fcabf1e", null ],
      [ "UHD_SENSOR_VALUE_REALNUM", "sensors_8h.html#acc485fe487df83f53d5646640b3a5b74ad773d06c7a24b908f5043130ceeb0954", null ],
      [ "UHD_SENSOR_VALUE_STRING", "sensors_8h.html#acc485fe487df83f53d5646640b3a5b74a8067db89d3f2a057b81a837f63155d04", null ]
    ] ],
    [ "uhd_sensor_value_data_type", "sensors_8h.html#a23a8d12786d020e5d20d71a22f44d6bc", null ],
    [ "uhd_sensor_value_free", "sensors_8h.html#acda87bc16f52769f8c0d077d1639cc74", null ],
    [ "uhd_sensor_value_last_error", "sensors_8h.html#a296bc75338059445a2a2598fe8aba305", null ],
    [ "uhd_sensor_value_make_from_bool", "sensors_8h.html#a68458d1a20811ff57ce393ba09a4b081", null ],
    [ "uhd_sensor_value_make_from_int", "sensors_8h.html#a9079d2f3746af1a114c93df84bb27b95", null ],
    [ "uhd_sensor_value_make_from_realnum", "sensors_8h.html#a33fc3f7797205d72b2f821c10e49271c", null ],
    [ "uhd_sensor_value_make_from_string", "sensors_8h.html#a9b5025c5f24f3218c2313cac86918411", null ],
    [ "uhd_sensor_value_name", "sensors_8h.html#ad641011c37720c7ec99a719717140e20", null ],
    [ "uhd_sensor_value_to_bool", "sensors_8h.html#ae6569e55bba10a5308ca6f9e53282684", null ],
    [ "uhd_sensor_value_to_int", "sensors_8h.html#aa5849ff3965fa007277e0d47d2584710", null ],
    [ "uhd_sensor_value_to_pp_string", "sensors_8h.html#a516410ccb2e6b76e2f1855ddf8ff36f3", null ],
    [ "uhd_sensor_value_to_realnum", "sensors_8h.html#aaa4e467ee5e4c0d423c476e8c70c8ffa", null ],
    [ "uhd_sensor_value_unit", "sensors_8h.html#af326947e74fdb79453d801c3efec0e57", null ],
    [ "uhd_sensor_value_value", "sensors_8h.html#a5f6ac5429b73d26224e9483f564f5fd2", null ]
];