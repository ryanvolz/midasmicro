var thread__priority_8hpp =
[
    [ "set_thread_priority", "thread__priority_8hpp.html#a986753a5e8ce8d7f34d1d15e3804ca03", null ],
    [ "set_thread_priority_safe", "thread__priority_8hpp.html#aa464d9cc8c59391af3f9e336230ae985", null ]
];