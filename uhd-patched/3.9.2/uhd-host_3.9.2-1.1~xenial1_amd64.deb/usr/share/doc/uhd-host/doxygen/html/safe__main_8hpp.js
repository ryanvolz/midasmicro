var safe__main_8hpp =
[
    [ "UHD_SAFE_MAIN", "safe__main_8hpp.html#aea70e5b03053a39fef463dc6b64682ac", null ]
];