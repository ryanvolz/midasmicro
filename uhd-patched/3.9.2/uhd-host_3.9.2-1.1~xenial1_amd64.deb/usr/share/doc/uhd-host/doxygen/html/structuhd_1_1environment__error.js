var structuhd_1_1environment__error =
[
    [ "environment_error", "structuhd_1_1environment__error.html#a0ab44fd16fcfc786a52d43f2f4e89ea9", null ],
    [ "code", "structuhd_1_1environment__error.html#a62f8a1d722e9e23ad37d49ebd414b17f", null ],
    [ "dynamic_clone", "structuhd_1_1environment__error.html#a1506f39a354b26f73f619f7173db4e6e", null ],
    [ "dynamic_throw", "structuhd_1_1environment__error.html#a5ff15f0c68ad7395fc246bbe031f967d", null ]
];