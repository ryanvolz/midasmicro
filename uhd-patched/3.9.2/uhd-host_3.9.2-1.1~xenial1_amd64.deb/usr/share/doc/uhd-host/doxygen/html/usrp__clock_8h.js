var usrp__clock_8h =
[
    [ "uhd_usrp_clock_handle", "usrp__clock_8h.html#ab1deef86e49eaef8c78e9f93adbedbf5", null ],
    [ "uhd_usrp_clock_find", "usrp__clock_8h.html#a41077f640afa9e70d34f02c3dab30bbd", null ],
    [ "uhd_usrp_clock_free", "usrp__clock_8h.html#a066d9d253a2d8c1c94711df2c7acb5aa", null ],
    [ "uhd_usrp_clock_get_num_boards", "usrp__clock_8h.html#a887be66d21a7203c5b508b9a6d178d0d", null ],
    [ "uhd_usrp_clock_get_pp_string", "usrp__clock_8h.html#acba99b1e3c0c9d37b255a20033ad5d13", null ],
    [ "uhd_usrp_clock_get_sensor", "usrp__clock_8h.html#a8df7341c34b61c93520733f68579d3d2", null ],
    [ "uhd_usrp_clock_get_sensor_names", "usrp__clock_8h.html#a57fab256e318f6e62ae649b459c9b6e1", null ],
    [ "uhd_usrp_clock_get_time", "usrp__clock_8h.html#a3768ebd9dac3c3168a950a255af1b1e7", null ],
    [ "uhd_usrp_clock_last_error", "usrp__clock_8h.html#aefa249a4d7c885d1d9a450ef144c6daa", null ],
    [ "uhd_usrp_clock_make", "usrp__clock_8h.html#af95f10d34d0e759856770cf9986689bf", null ]
];