var structuhd_1_1stream__args__t =
[
    [ "stream_args_t", "structuhd_1_1stream__args__t.html#aa54b7dc3e2c71d11c774d8b4a15984cc", null ],
    [ "args", "structuhd_1_1stream__args__t.html#a4463f2eec2cc7ee70f84baacbb26e1ef", null ],
    [ "channels", "structuhd_1_1stream__args__t.html#aebfb903c0cb6c040d78ef90917e55a61", null ],
    [ "cpu_format", "structuhd_1_1stream__args__t.html#a602a64b4937a85dba84e7f724387e252", null ],
    [ "otw_format", "structuhd_1_1stream__args__t.html#a0ba0e946d2f83f7ac085f4f4e2ce9578", null ]
];