var structuhd__stream__cmd__t =
[
    [ "num_samps", "structuhd__stream__cmd__t.html#afe015eed3c5fde54c0eed00a9b39e537", null ],
    [ "stream_mode", "structuhd__stream__cmd__t.html#a7a554a47849307827e4e067a3c7a3db3", null ],
    [ "stream_now", "structuhd__stream__cmd__t.html#a49d87875f02323627803db3df305b43b", null ],
    [ "time_spec_frac_secs", "structuhd__stream__cmd__t.html#a8fa18e362af7bcfc17bb00908fb6df9f", null ],
    [ "time_spec_full_secs", "structuhd__stream__cmd__t.html#aa1bdad1ca6f2bf752dc72d40ba4a2baf", null ]
];