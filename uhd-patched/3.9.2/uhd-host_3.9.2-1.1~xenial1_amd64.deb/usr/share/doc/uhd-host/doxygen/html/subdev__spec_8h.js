var subdev__spec_8h =
[
    [ "uhd_subdev_spec_pair_t", "structuhd__subdev__spec__pair__t.html", "structuhd__subdev__spec__pair__t" ],
    [ "uhd_subdev_spec_handle", "subdev__spec_8h.html#adac2e5b85e65eadbb79dc15ae6095ec8", null ],
    [ "uhd_subdev_spec_at", "subdev__spec_8h.html#ac0b385573abd2826188f897f702003fe", null ],
    [ "uhd_subdev_spec_free", "subdev__spec_8h.html#ae00705a2a16339cff524c2fc42e3543f", null ],
    [ "uhd_subdev_spec_last_error", "subdev__spec_8h.html#af3c635e1231df559abc25d23cc373447", null ],
    [ "uhd_subdev_spec_make", "subdev__spec_8h.html#a6f66e55eb395584f1d0283c39d1d1b4f", null ],
    [ "uhd_subdev_spec_pair_free", "subdev__spec_8h.html#a44502359a70ae5b7d9f1a9d732dd6a69", null ],
    [ "uhd_subdev_spec_pairs_equal", "subdev__spec_8h.html#aea183be4db7830550c1cd552d14354e3", null ],
    [ "uhd_subdev_spec_push_back", "subdev__spec_8h.html#a7022a55ac5e00cca807ed38e36502557", null ],
    [ "uhd_subdev_spec_size", "subdev__spec_8h.html#a116dd4fa9ac4d62f5d4486afbc764fe4", null ],
    [ "uhd_subdev_spec_to_pp_string", "subdev__spec_8h.html#af8e69e5f35aa828641c6618f5cd3c3e1", null ],
    [ "uhd_subdev_spec_to_string", "subdev__spec_8h.html#a3a109f456302b25150354e30e5975a5a", null ]
];