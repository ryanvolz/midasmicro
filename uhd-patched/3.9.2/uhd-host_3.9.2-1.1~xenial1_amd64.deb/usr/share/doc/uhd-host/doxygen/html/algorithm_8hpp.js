var algorithm_8hpp =
[
    [ "clip", "algorithm_8hpp.html#a694cb04def95e7e68420af4212f138b9", null ],
    [ "has", "algorithm_8hpp.html#a0057d856ade9a26f2b0faa9df0049b0e", null ],
    [ "reversed", "algorithm_8hpp.html#acfa26a44d57b31a4ab555b40c0560432", null ],
    [ "sorted", "algorithm_8hpp.html#ac27cbcfef19a21e5d5e0469c9bde5cc5", null ]
];