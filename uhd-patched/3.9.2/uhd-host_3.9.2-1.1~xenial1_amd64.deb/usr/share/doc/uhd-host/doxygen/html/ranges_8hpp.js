var ranges_8hpp =
[
    [ "range_t", "classuhd_1_1range__t.html", "classuhd_1_1range__t" ],
    [ "meta_range_t", "structuhd_1_1meta__range__t.html", "structuhd_1_1meta__range__t" ],
    [ "freq_range_t", "ranges_8hpp.html#a948ed1f408f7737060d0b6a5d75a135d", null ],
    [ "gain_range_t", "ranges_8hpp.html#ac9b64ecbaa15596e07f58122c82482e3", null ]
];