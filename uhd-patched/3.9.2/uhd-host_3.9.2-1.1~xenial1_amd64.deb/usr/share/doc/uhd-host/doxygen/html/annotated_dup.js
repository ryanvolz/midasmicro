var annotated_dup =
[
    [ "uhd", "namespaceuhd.html", "namespaceuhd" ],
    [ "_uhd_static_fixture", "struct__uhd__static__fixture.html", "struct__uhd__static__fixture" ],
    [ "uhd_range_t", "structuhd__range__t.html", "structuhd__range__t" ],
    [ "uhd_stream_args_t", "structuhd__stream__args__t.html", "structuhd__stream__args__t" ],
    [ "uhd_stream_cmd_t", "structuhd__stream__cmd__t.html", "structuhd__stream__cmd__t" ],
    [ "uhd_subdev_spec_pair_t", "structuhd__subdev__spec__pair__t.html", "structuhd__subdev__spec__pair__t" ],
    [ "uhd_tune_request_t", "structuhd__tune__request__t.html", "structuhd__tune__request__t" ],
    [ "uhd_tune_result_t", "structuhd__tune__result__t.html", "structuhd__tune__result__t" ],
    [ "uhd_usrp_register_info_t", "structuhd__usrp__register__info__t.html", "structuhd__usrp__register__info__t" ],
    [ "uhd_usrp_rx_info_t", "structuhd__usrp__rx__info__t.html", "structuhd__usrp__rx__info__t" ],
    [ "uhd_usrp_tx_info_t", "structuhd__usrp__tx__info__t.html", "structuhd__usrp__tx__info__t" ]
];