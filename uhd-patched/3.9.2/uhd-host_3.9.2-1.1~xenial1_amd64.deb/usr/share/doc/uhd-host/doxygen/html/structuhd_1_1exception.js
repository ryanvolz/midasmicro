var structuhd_1_1exception =
[
    [ "exception", "structuhd_1_1exception.html#a397d45e23bb2c1683cf03553b11581f9", null ],
    [ "code", "structuhd_1_1exception.html#a8d01eae8ad0a250bb641e89a60295a9a", null ],
    [ "dynamic_clone", "structuhd_1_1exception.html#af065f4ea3aa5d72cd12576c452a01f4a", null ],
    [ "dynamic_throw", "structuhd_1_1exception.html#a3f1f6015350be24f040e123368c04081", null ]
];