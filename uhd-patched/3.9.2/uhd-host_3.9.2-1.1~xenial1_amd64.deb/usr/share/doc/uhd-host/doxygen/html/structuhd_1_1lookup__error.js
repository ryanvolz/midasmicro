var structuhd_1_1lookup__error =
[
    [ "lookup_error", "structuhd_1_1lookup__error.html#ae0ee2d4f66343345de42286fd560f989", null ],
    [ "code", "structuhd_1_1lookup__error.html#a7a1b6020e78c85eb3740c168448d08e4", null ],
    [ "dynamic_clone", "structuhd_1_1lookup__error.html#a20a34aa4b11cd0d2a50a2203c1f71e25", null ],
    [ "dynamic_throw", "structuhd_1_1lookup__error.html#a61c669bcbf8d7625fc23c52a01ac1a24", null ]
];