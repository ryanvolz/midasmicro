var dict_8ipp =
[
    [ "INCLUDED_UHD_TYPES_DICT_IPP", "dict_8ipp.html#a9d75c4de575e31e4ec5ebc6faf6b5382", null ]
];