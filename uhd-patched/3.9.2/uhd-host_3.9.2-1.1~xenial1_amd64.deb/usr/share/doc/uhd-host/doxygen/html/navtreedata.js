var NAVTREE =
[
  [ "USRP Hardware Driver and USRP Manual", "index.html", [
    [ "Table Of Contents", "index.html", "index" ],
    [ "Namespaces", null, [
      [ "Namespace List", "namespaces.html", "namespaces" ],
      [ "Namespace Members", "namespacemembers.html", [
        [ "All", "namespacemembers.html", null ],
        [ "Functions", "namespacemembers_func.html", null ],
        [ "Typedefs", "namespacemembers_type.html", null ],
        [ "Enumerations", "namespacemembers_enum.html", null ],
        [ "Enumerator", "namespacemembers_eval.html", null ]
      ] ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", "functions_dup" ],
        [ "Functions", "functions_func.html", "functions_func" ],
        [ "Variables", "functions_vars.html", null ],
        [ "Typedefs", "functions_type.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Enumerator", "functions_eval.html", null ]
      ] ]
    ] ],
    [ "Files", null, [
      [ "File List", "files.html", "files" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", "globals_dup" ],
        [ "Functions", "globals_func.html", "globals_func" ],
        [ "Typedefs", "globals_type.html", null ],
        [ "Enumerations", "globals_enum.html", null ],
        [ "Enumerator", "globals_eval.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"algorithm_8hpp.html",
"classuhd_1_1property__tree.html#a7a1624d69da606fc05bc7fba7f0f6026",
"classuhd_1_1usrp_1_1dboard__base.html",
"dboard__eeprom_8h.html#aa37096bcf0fff9da8d04dfb3fa7adcf4",
"math_8hpp.html#a3bdee7b9abaa03195ddcd028e9c15581",
"page_general.html#general_tuning",
"page_usrp_e3x0.html#e3x0_hw_fpanel",
"structuhd_1_1async__metadata__t.html#a2be1b5c0351746c78fa3bcb74a8ff5daa0f682672d74109515266ec07e70c0ebc",
"structuhd_1_1tune__result__t.html#a6f4fdd6b4dd360e0fa31c847c50e3b7d",
"usrp_8h.html#abd8092e611db36e984228bad9bf81cd8"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';