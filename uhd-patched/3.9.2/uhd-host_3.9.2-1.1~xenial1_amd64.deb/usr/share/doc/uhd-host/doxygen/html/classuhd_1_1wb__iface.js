var classuhd_1_1wb__iface =
[
    [ "sptr", "classuhd_1_1wb__iface.html#a2369ba0ac501d4b309f181063c13aa3f", null ],
    [ "wb_addr_type", "classuhd_1_1wb__iface.html#a31cd5565a1971e19ba742ed8c23b3e50", null ],
    [ "~wb_iface", "classuhd_1_1wb__iface.html#a77a19452ba6946c417ba025cef7fc6b4", null ],
    [ "peek16", "classuhd_1_1wb__iface.html#a668567f1f8ef4284e67db4a70840ee8d", null ],
    [ "peek32", "classuhd_1_1wb__iface.html#af381354d2ae7d46f3b52ba8ec730355c", null ],
    [ "peek64", "classuhd_1_1wb__iface.html#ae6e6ad668eee4e629e955bd1313bb94a", null ],
    [ "poke16", "classuhd_1_1wb__iface.html#ad17d23d3c32ee42e5b274e60b8352614", null ],
    [ "poke32", "classuhd_1_1wb__iface.html#a32f1a47b8d4e7e7e3d61d448ae544850", null ],
    [ "poke64", "classuhd_1_1wb__iface.html#a5cbc5f891d85e32802c34efeee8e2733", null ]
];